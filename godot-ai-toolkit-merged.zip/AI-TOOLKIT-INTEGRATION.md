# Godot AI Toolkit integration

This folder is a community companion for AI-assisted Godot development. It is not official Godot documentation and does not change upstream licences.

Start at [`ai-toolkit/README.md`](ai-toolkit/README.md). Read [`ai-toolkit/INTEGRATION.md`](ai-toolkit/INTEGRATION.md) before adding this folder to a fork of the official documentation. Preserve all upstream files and notices.
