# Contributing

- Keep guidance clear, practical and version-aware.
- Link to official Godot documentation for engine-specific details.
- Do not present changing platform requirements as permanent facts.
- Preserve upstream copyright, attribution and licence notices.
- Check licences for added code, assets and examples.
- Test code examples in the stated engine version before calling them verified.
- Keep contributions focused and explain the reason for each change.
