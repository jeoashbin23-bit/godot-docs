# Common Godot Game Systems — Design Notes

These are architecture starting points, not drop-in plugins. Adapt them to your project's scene tree and Godot version.

## Player controller

Separate input collection, movement, animation and combat decisions. Keep movement state explicit (for example: idle, run, jump, fall, attack, hurt). Avoid having multiple scripts independently control the same velocity or animation state.

## Health and damage

Use a clear health owner and a single damage entry point. Validate damage values, clamp health to its valid range, emit signals when health changes and handle death once. Decide how invulnerability frames and damage sources work.

## Enemy AI

Start with a small state machine: idle, patrol, chase, attack, hurt, dead. Separate sensing from decision-making and movement. Add navigation only when the level requires it. Test edge cases such as losing the player, reaching a ledge and being interrupted during an attack.

## Inventory

Define item identity and stack rules before building UI. Keep inventory data separate from display nodes. Validate item counts and handle full inventory, duplicate items and save/load migration.

## Save system

Define a versioned save schema. Validate loaded data and provide safe defaults for missing fields. Save only necessary game state. Test corrupted, missing and older save files. Never store credentials or sensitive personal data in game saves.

## Mobile controls

Keep input actions abstract so touch controls and keyboard/controller can drive the same gameplay actions. Test button sizing, multitouch, UI safe areas and controls across aspect ratios.

## Architecture rule

Choose the simplest structure that supports the current game. Avoid introducing global singletons, complex event buses or generic frameworks before the project needs them.
