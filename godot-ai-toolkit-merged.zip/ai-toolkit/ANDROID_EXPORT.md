# Godot Android Export Checklist

This is a release checklist, not a substitute for the official export documentation. Export templates, Android SDK, JDK and Gradle requirements vary by Godot version.

## Before setup

- [ ] Confirm the exact Godot 4.x version.
- [ ] Install the matching export templates from the editor.
- [ ] Follow the official documentation for the matching version to install/configure OpenJDK and Android SDK.
- [ ] Confirm the required SDK platform/build-tools versions for that Godot release.
- [ ] Test a minimal blank project export before configuring the full game.

## Project configuration

- [ ] Set a unique application/package identifier.
- [ ] Set app name, version and version code.
- [ ] Choose orientation and supported screen behaviour.
- [ ] Configure permissions only when the game genuinely needs them.
- [ ] Test touch controls and UI scaling on multiple aspect ratios.
- [ ] Check audio focus, pause/resume and Android back behaviour.
- [ ] Remove debug-only settings and test release behaviour.

## Release signing and Play

- [ ] Create and securely back up the release signing key.
- [ ] Never commit keystores, passwords or signing credentials to Git.
- [ ] Export the format currently required by Google Play (normally Android App Bundle for new Play releases; verify current Play Console requirements).
- [ ] Test the release build on a physical device.
- [ ] Check package ID, versioning, app icon, screenshots, content rating and store listing.
- [ ] Complete Play Console testing and policy declarations.
- [ ] Keep a secure backup of signing material.

## Troubleshooting

1. Read the complete export error, not only the last line.
2. Confirm Godot version and export templates match.
3. Confirm SDK/JDK paths and required versions.
4. Try exporting a blank project to isolate environment problems.
5. Change one setting at a time and record the result.

Official reference: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html
