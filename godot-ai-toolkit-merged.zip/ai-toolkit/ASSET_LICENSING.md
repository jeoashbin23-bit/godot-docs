# Asset and AI-Content Licensing

For every third-party or AI-generated asset, record:
- name and creator/provider;
- source URL and date obtained;
- licence/terms version;
- commercial-use permission;
- attribution requirements;
- modification and redistribution restrictions;
- proof of purchase or permission, if applicable.

Remember:
- Free download does not automatically mean commercial use is allowed.
- A repository code licence may not cover its artwork, fonts, sounds or sample files.
- A subscription does not automatically grant unrestricted rights to every input/output.
- Check whether an asset may be embedded and redistributed inside a game.
- Keep upstream Godot notices and licences intact.

This guide is not legal advice. When rights are unclear, do not ship the asset until permission is confirmed.
