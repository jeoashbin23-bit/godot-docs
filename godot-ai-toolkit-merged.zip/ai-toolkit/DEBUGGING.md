# Debugging Method

1. Reproduce the issue.
2. Capture the exact error and stack trace.
3. Record Godot version, platform and renderer.
4. Identify the scene and script involved.
5. Reduce the issue to the smallest reproducible case.
6. Change one likely cause at a time.
7. Repeat the reproduction steps.
8. Check related gameplay for regressions.

When asking AI for help, provide expected behaviour, actual behaviour, reproduction steps and the relevant code/scene context. Redact tokens, passwords and personal data from logs.
