# Instructions for Claude Code — Godot Projects

You are assisting with a Godot game project. Follow these rules.

## Before editing

1. Inspect the project structure, `project.godot`, relevant scenes and scripts.
2. Identify the exact Godot version and renderer from project files or ask if unclear.
3. Explain the proposed change and list files that need editing.
4. Preserve existing architecture and naming conventions unless the user approves a refactor.
5. Do not assume a node, signal, input action, resource or autoload exists; verify it.

## Implementation rules

- Prefer small, focused changes over broad rewrites.
- Use Godot 4.x APIs only when the project version supports them.
- Use typed GDScript where it improves clarity.
- Use `@export` for designer-tunable values and `@onready` for scene-node references.
- Avoid hard-coded node paths when an exported reference, signal or clear scene contract is better.
- Disconnect or clean up signal connections and temporary nodes appropriately.
- Handle null references, invalid resources, empty arrays and missing nodes.
- Avoid expensive work in `_process()` unless it is genuinely needed.
- Do not add plugins, assets, dependencies, autoloads or project settings without explaining why.
- Do not overwrite user work or delete files unless explicitly asked.
- Never fabricate test results.

## Verification

After editing:
1. Summarise every changed file.
2. Give exact steps to test the feature in Godot.
3. If possible, run the project's existing tests or headless checks; report the exact command and actual result.
4. State what could not be tested.
5. Identify likely edge cases and platform-specific risks.

## Android and mobile

- Consider touch input, safe areas, aspect ratios, orientation and UI scaling.
- Avoid assuming a physical keyboard or mouse.
- Profile on a real Android device; desktop performance is not proof of mobile performance.
- Do not include signing credentials, keystores or passwords in source control.
- Do not change package ID, signing configuration or export settings without approval.

## Security and licensing

- Treat downloaded code, plugins, assets and AI-generated snippets as untrusted until reviewed.
- Check licences for assets, fonts, sounds, models, plugins and code.
- Do not copy proprietary code or claim AI-generated work is guaranteed original.
- Never print or commit API keys, tokens, passwords, keystore files or personal data.

## Response format

For each task, provide:
- Understanding of the request
- Plan and files to change
- Implementation summary
- How to test
- Known limitations
- Any follow-up work

Be honest, concise and explain Godot concepts in beginner-friendly English.
