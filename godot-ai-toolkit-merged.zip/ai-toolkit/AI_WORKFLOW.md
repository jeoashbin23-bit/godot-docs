# AI-Assisted Godot Development Workflow

## 1. Start with a project brief

Record:
- Game genre and core gameplay loop
- Godot version and renderer
- Target platform and minimum device
- Input methods
- Resolution and orientation
- Art/audio sources and their licences
- Performance target
- Current bugs and known limitations

## 2. Ask AI to inspect, not immediately rewrite

Prompt it to map scenes, scripts, autoloads, input actions, resources and project settings. Ask for file paths and evidence from the project. Correct any mistaken assumptions before coding.

## 3. Define acceptance criteria

A feature is complete only when its behaviour can be observed and tested. Include normal cases, failure cases, save/load behaviour and mobile input where relevant.

## 4. Implement in small slices

Make one coherent change at a time. Ask for a short explanation before broad refactors. Keep a working baseline and review the diff.

## 5. Verify

- Run the scene in the editor.
- Check the Output and Debugger panels.
- Test missing references and invalid inputs.
- Test pause/resume, scene changes and restart.
- Test different resolutions and aspect ratios.
- Test on target hardware.
- Run automated tests if the project has them.

## 6. Review AI output

Check API names against the correct Godot version. Look for unnecessary `_process()` work, repeated resource loading, unbounded node creation, signal leaks, unsafe file paths, brittle node paths and hidden dependencies.

## 7. Preserve project history

Use Git commits with focused messages. Do not commit generated caches, secrets, signing keys or large assets unless intentionally required. Keep a backup before large changes.
