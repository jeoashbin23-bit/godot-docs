# Integrating the Toolkit into a Godot Documentation Fork

This toolkit is a standalone companion section. It must not replace upstream Godot documentation.

## Safe integration

1. Keep the upstream source, README, build configuration, copyright notices and licence files unchanged.
2. Add this `ai-toolkit/` directory as a clearly separated community resource.
3. Add a small navigation link only if you intentionally maintain your fork's navigation and have checked its Sphinx/reStructuredText conventions.
4. Do not change global Sphinx configuration merely to publish Markdown pages. Markdown may not be included in the existing documentation build.
5. Build using the repository's documented process and inspect the rendered output before publishing.
6. Clearly label the material unofficial and version-sensitive.

## Suggested repository note

“This repository is a fork of the official Godot documentation. The `ai-toolkit/` directory contains separate, unofficial community guidance for AI-assisted Godot development. It does not replace or modify the upstream manual.”

## Validation

Before merging, inspect the diff, verify that no upstream file or licence was removed, check links, and record exactly which build and tests were run.
