# Godot AI Development Toolkit — Community Edition

An unofficial, English-language companion toolkit for Godot 4.x developers using ChatGPT, Claude, Claude Code or other AI assistants. It combines the Pro Plus guide set with the expanded AI-enhancement guides and prompt templates.

> This is documentation and reusable workflow material—not a Godot plugin, engine modification, official Godot project, or guarantee that AI-generated code is correct.

## Start here

1. [AI assistant rules](AI_ASSISTANT_RULES.md)
2. [AI-assisted workflow](AI_WORKFLOW.md)
3. [Claude Code instructions](CLAUDE.md)
4. [Project structure](PROJECT_STRUCTURE.md)
5. [GDScript style](GDSCRIPT_STYLE.md)
6. [Common game systems](GAME_SYSTEMS.md)
7. [Testing and QA](TESTING_QA.md) and [debugging](DEBUGGING.md)
8. [Performance and mobile optimisation](PERFORMANCE.md)
9. [Android export](ANDROID_EXPORT.md) and [release checklist](RELEASE_CHECKLIST.md)
10. [Asset licensing](ASSET_LICENSING.md) and [security](SECURITY.md)

## Prompt library

See [prompts/](prompts/README.md) for project audits, feature planning, GDScript review, debugging, Android release review, performance audits, test plans, save systems, mobile UI, game design and localisation.

## Templates

See [templates/](templates/README.md) for feature specifications, bug reports, release notes and an asset register.

## Recommended use

- Tell the assistant the exact Godot version, renderer, language and target platforms.
- Ask it to inspect relevant files before editing.
- Work in small changes and review every diff.
- Run the project and tests; test on actual target devices.
- Ask for an honest report of what was and was not tested.
- Never share passwords, API keys, signing credentials or private player data.

## Compatibility

General Godot 4.x guidance. APIs and export requirements vary by engine version and platform. Verify against the official documentation for the exact version used by your project.

## Licensing and attribution

This companion material does not change the licence of the upstream Godot documentation or any third-party material. Keep upstream copyright and licence files intact. Check each code sample, plugin, asset, font, model and sound separately before commercial use. Free download does not automatically mean commercial redistribution is allowed.
