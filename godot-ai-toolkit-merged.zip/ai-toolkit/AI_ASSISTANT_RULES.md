# Rules for AI Coding Assistants

- Use the exact engine version specified by the project owner.
- Inspect the relevant project files before proposing changes.
- Do not invent node paths, signals, resources, autoloads, input actions or project settings.
- Prefer the smallest focused change that meets the acceptance criteria.
- Preserve existing behaviour unless the task explicitly changes it.
- Do not add plugins, analytics, network calls or dependencies without approval.
- Explain assumptions and risks.
- Use clear names and consistent style; add static types where they improve clarity.
- Do not silently change project architecture or move/rename files.
- Never commit credentials, signing keys, tokens or private user data.
- Keep licence notices and asset provenance.
- Provide a test plan and report only tests actually run.
- For mobile, consider touch input, safe areas, aspect ratios, memory, battery and thermal limits.
- Do not claim an export or release is successful without actually building and testing it.
- Finish with changed files, tests, limitations and rollback guidance.
