# Release Checklist

## Game
- [ ] Correct engine version and export templates.
- [ ] Main gameplay paths tested.
- [ ] Save/load, pause/resume, restart and quit tested.
- [ ] Errors and warnings reviewed.
- [ ] Performance checked on target hardware.
- [ ] UI readability and accessibility reviewed.

## Android
- [ ] Correct package ID and version.
- [ ] Release signing configured and backed up.
- [ ] Release candidate installed on a physical device.
- [ ] Permissions reviewed and minimised.
- [ ] Store icon, screenshots and listing prepared.

## Legal and store
- [ ] Asset/plugin licences recorded.
- [ ] Privacy/data disclosures accurate where required.
- [ ] Content rating and current store declarations completed.
- [ ] Current Play policy and target API requirements checked.
- [ ] No secrets or debug credentials included.

## Final
- [ ] Exact upload file tested.
- [ ] Release notes prepared.
- [ ] Build and source commit recorded.
