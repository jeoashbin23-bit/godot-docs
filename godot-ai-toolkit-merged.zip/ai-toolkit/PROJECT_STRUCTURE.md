# Project Structure

Choose a structure that suits the project. Do not reorganise a working game only to match this example.

```text
res://
  assets/
    audio/
    fonts/
    materials/
    models/
    textures/
    ui/
  scenes/
    levels/
    player/
    enemies/
    interface/
  scripts/
    player/
    enemies/
    systems/
    ui/
  resources/
    items/
    abilities/
    balance/
  tests/
  docs/
  project.godot
```

## Keep the project maintainable

- Group assets by purpose or feature.
- Use consistent file names.
- Keep reusable game data separate from runtime state.
- Document autoloads and global signals.
- Avoid duplicate large assets.
- Check resource references before moving or renaming files.
- Keep generated/imported files under the project's existing ignore and source-control rules.
