# Game Design Review

Game concept: [CONCEPT]
Target player: [AUDIENCE]
Platform: [PLATFORM]
Core loop: [CORE LOOP]
Session length: [SESSION]
Constraints: [TEAM/BUDGET/SCOPE]

Evaluate clarity, player motivation, progression, difficulty, replay value and production scope. Identify risks and propose a small prototype test before expanding. Do not assume features are feasible without estimating content and implementation effort.
