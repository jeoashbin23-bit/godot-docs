# GDScript Review Prompt

Review the supplied GDScript for the project's exact Godot version.

Check correctness, typing, null safety, node paths, signal lifecycle, state handling, performance, readability and mobile implications. Identify issues by file and line where possible.

For each issue, explain impact and propose a minimal fix. Separate confirmed bugs from possible risks. Do not rewrite unrelated code and do not claim the code was tested unless you actually ran it.
