# Performance Audit

Godot version: [VERSION]
Device: [DEVICE]
Observed issue: [FRAME TIME/FPS/MEMORY/LOADING]
Reproduction: [STEPS]
Profiler evidence: [DATA]

Use evidence to identify bottlenecks. Prioritise measurable low-risk changes. Explain how to compare before/after. Do not optimise without a measurement plan.
