# Project Audit Prompt

Act as a senior Godot developer. Audit this project without changing files.

Godot version: [exact version]
Renderer: [Forward+/Mobile/Compatibility/unknown]
Target: [Android/PC/both]
Language: [GDScript/C#]

Inspect the project structure, project settings, scenes, scripts, autoloads, input actions and resource dependencies. Report:
1. A concise architecture map with real file paths.
2. Main gameplay entry points and scene transitions.
3. Existing conventions worth preserving.
4. Bugs or risks supported by evidence.
5. Android/mobile concerns, if relevant.
6. A prioritised improvement plan.

Do not assume files or nodes exist. Quote exact paths. Do not edit anything.
