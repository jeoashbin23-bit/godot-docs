# Feature Planning Prompt

Plan this feature for my existing Godot project: [feature]

Godot version: [version]
Target platforms: [platforms]
Relevant scenes/scripts: [paths, if known]
Constraints: [performance, controls, art, deadline]

First inspect relevant project files. Then propose:
- Expected player-visible behaviour
- Scene/node design
- Script and resource changes
- Signals and data flow
- Edge cases and failure handling
- Acceptance criteria and manual test steps

Do not implement until the plan is approved. Prefer the smallest maintainable solution.
