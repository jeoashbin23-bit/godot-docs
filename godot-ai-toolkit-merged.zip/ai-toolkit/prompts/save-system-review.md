# Save System Review

Review the supplied Godot save/load code for [VERSION]. Check data validation, versioning, missing/corrupt files, interrupted writes, default values, migration and privacy. Propose a safe test matrix. Do not claim durability or security without evidence. Never include real player data in examples.
