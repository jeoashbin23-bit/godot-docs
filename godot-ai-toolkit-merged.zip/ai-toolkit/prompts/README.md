# Reusable AI Prompts

Replace bracketed details with facts from your project. Give the assistant the relevant files and exact Godot version.

- `project-audit.md` — inspect an existing project
- `feature-plan.md` — plan a feature before coding
- `gdscript-review.md` — review scripts
- `debug-error.md` — diagnose an error
- `android-release-review.md` — review Android readiness

Do not ask AI to invent test results. Ask it to state what it actually ran and what remains unverified.
