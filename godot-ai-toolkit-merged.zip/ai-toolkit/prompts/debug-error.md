# Godot Debugging Prompt

Help diagnose this Godot error.

Godot version: [version]
Platform: [platform]
Exact error and stack trace:
[paste complete error]

Steps to reproduce:
[steps]

Expected result:
[expected]

Actual result:
[actual]

Relevant files:
[paths or contents]

Inspect the supplied evidence first. Explain the likely root cause, how to verify it, and the smallest safe fix. If information is missing, ask for the most important missing detail rather than guessing.
