# Localisation Review

Review these Godot UI strings for [LANGUAGES]. Check translation keys, context, placeholders, text expansion, line breaks, font coverage, right-to-left needs and input formatting. Do not translate proper names or technical terms without context. Flag strings that need a native-speaker review. Test rendered text in the actual UI.
