# Test Plan

Feature: [FEATURE]
Godot version: [VERSION]
Platforms: [PLATFORMS]
Acceptance criteria: [CRITERIA]
Relevant files: [FILES]

Create tests with setup, action and expected result. Include normal paths, edge cases, failures, regressions and device-specific checks. Separate automated from manual tests.
