# Android Release Review Prompt

Review this Godot project for Android release readiness.

Godot version: [version]
Target Android devices: [minimum device/OS]
Play release track: [internal/closed/open/production]

Check export settings, package ID, versioning, permissions, touch controls, UI scaling, pause/resume, audio, performance, memory, signing-key handling and release-build behaviour.

Return a checklist with:
- Confirmed ready items and evidence
- Blockers
- Risks requiring a physical-device test
- Exact next steps

Do not request or expose passwords, keystores or signing secrets. Do not claim Play policy compliance without checking current official requirements.
