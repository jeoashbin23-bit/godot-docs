# Architecture Decision Log

Use this file to record important project decisions. For larger projects, create one Markdown file per decision in `docs/decisions/`.

## Template

### Decision: [Short title]
- Date:
- Status: proposed / accepted / superseded
- Context:
- Options considered:
- Decision:
- Consequences and trade-offs:
- Godot version:
- Related files/issues:

Record why a decision was made, not only what was chosen. This helps future contributors and AI assistants avoid proposing incompatible changes.
