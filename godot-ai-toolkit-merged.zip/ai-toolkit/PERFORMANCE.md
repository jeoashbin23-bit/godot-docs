# Godot Performance Checklist

## Measure first

- Use the Godot profiler and debugger before optimising.
- Identify whether the bottleneck is CPU, GPU, memory, disk, network or scripting.
- Test on the lowest-spec target device, not only a development PC.
- Record frame time, memory use, loading time and battery/thermal behaviour.

## Common improvements to investigate

- Reduce unnecessary work in `_process()` and `_physics_process()`.
- Use signals or event-driven updates when continuous polling is unnecessary.
- Reuse or pool frequently spawned objects when profiling shows allocation spikes.
- Limit expensive physics queries and collision shapes.
- Use appropriate texture sizes and compression.
- Avoid excessive transparent overdraw and expensive full-screen effects.
- Use LOD, visibility ranges and occlusion strategies where suitable.
- Stream or load large resources deliberately; avoid loading everything at startup.
- Keep UI layouts and animations efficient on mobile.
- Avoid excessive nodes only when profiling demonstrates a real cost; do not optimise by guesswork.

## Mobile test pass

- Test low-end and mid-range devices.
- Test long sessions for heat and memory growth.
- Test background/foreground transitions.
- Test different screen densities and aspect ratios.
- Check battery usage and frame pacing, not only average FPS.
