# GDScript Style Notes

Follow the official style guidance for the exact engine version and the conventions already used by the project.

- Use `snake_case` for functions and variables.
- Use `PascalCase` for class names.
- Prefer clear, descriptive names over abbreviations.
- Add explicit types to exported values and public interfaces where practical.
- Keep functions focused and avoid deeply nested logic.
- Use constants for meaningful fixed values.
- Use signals to reduce unnecessary coupling between independent systems.
- Validate data loaded from files or external sources.
- Avoid repeated scene-tree searches in performance-critical code.
- Do not assume an API exists: verify it in the version-specific class reference.

Example:

```gdscript
extends CharacterBody2D

@export var move_speed: float = 220.0

func set_horizontal_input(direction: float) -> void:
    velocity.x = direction * move_speed
```

This is an illustrative snippet, not a complete controller. Confirm syntax and behaviour in your Godot version.
