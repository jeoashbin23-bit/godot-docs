# Bug Report

## Summary
[Short description]

## Environment
- Godot version:
- OS/device:
- Renderer:
- Build type:

## Steps to reproduce
1.
2.
3.

## Expected result
[What should happen?]

## Actual result
[What happens instead?]

## Error output
[Paste full relevant error/stack trace]

## Frequency
[Always / sometimes / once]

## Attachments
[Relevant scene, script, screenshot or minimal reproduction]
