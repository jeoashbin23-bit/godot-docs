# Release [VERSION] — [DATE]

## Highlights
- [Player-facing change]

## Improvements
- [Improvement]

## Bug fixes
- [Fix]

## Known issues
- [Known limitation]

## Verification
- Godot version:
- Platforms/devices tested:
- Tests actually run:
- Tests not run:
