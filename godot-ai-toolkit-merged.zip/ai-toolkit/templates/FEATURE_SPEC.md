# Feature Specification

## Summary
[What is being added?]

## Player behaviour
[What should the player see or experience?]

## Scope
### Included
- [ ]

### Not included
- [ ]

## Technical notes
- Godot version:
- Relevant scenes/scripts:
- Input methods:
- Save/load impact:
- Performance constraints:

## Acceptance criteria
- [ ] Normal flow works.
- [ ] Invalid or missing data is handled.
- [ ] Pause, restart and scene changes work.
- [ ] UI works at target resolutions.
- [ ] Target-device test completed.

## Test plan
[Steps and expected results]
