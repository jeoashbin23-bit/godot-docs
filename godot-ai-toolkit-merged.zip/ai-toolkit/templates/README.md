# Project Templates

Copy and adapt these templates for your own game repository.

- `FEATURE_SPEC.md` — define a feature and its acceptance criteria.
- `BUG_REPORT.md` — record reproducible bugs.
