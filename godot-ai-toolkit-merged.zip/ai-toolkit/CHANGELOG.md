# Changelog

## Community toolkit merge
- Combined the Pro Plus guide set with the expanded AI enhancement guides.
- Used the expanded editions for overlapping AI workflow, Claude Code, Android export, performance, game systems and prompt/template documents.
- Retained unique guides for security, asset licensing, GDScript style, QA, project structure, release process, decision logging and contribution.
- Kept the toolkit separate from upstream Godot documentation.
