# Testing and QA

## Manual smoke test

- Launch from the editor.
- Open the changed scene.
- Test the expected happy path.
- Test invalid inputs and boundary cases.
- Test pause/resume, scene changes and restart where relevant.
- Check Output and Debugger for errors.
- Test keyboard/mouse and touch controls as applicable.
- Test on target hardware for platform-specific behaviour.

## Useful gameplay regression cases

- Death and respawn.
- New game, save, load and corrupted save.
- Scene transition while UI is open.
- Pause during combat or animation.
- App background/foreground on mobile.
- Interrupted touch input and multi-touch.
- Audio focus and mute.
- Repeated scene loading for memory growth.

## Report

Record engine version, platform, steps, expected result, actual result, evidence and tests not performed. Never mark a test as passed if it was not run.
