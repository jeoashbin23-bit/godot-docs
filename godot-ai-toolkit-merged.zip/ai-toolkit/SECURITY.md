# Security and Privacy

- Never commit API keys, passwords, tokens, signing keys or private certificates.
- Store secrets outside source control or in an appropriate secure CI secret store.
- Do not log credentials or unnecessary personal/player data.
- Request only platform permissions the game needs.
- Validate data loaded from files, network responses and user input.
- Use HTTPS for network services.
- Do not trust client-side values for purchases, rewards or competitive scores.
- Review plugins and dependencies before adding them.
- Remove test credentials and debug endpoints from release builds.

If a secret is committed, revoke/rotate it. Removing it from the latest commit does not necessarily remove it from Git history.
